{
    "error": true,
    "code": 404,
    "message": "<?= $message ?? 'Page Not Found' ?>",
    "timestamp": "<?= date('Y-m-d H:i:s') ?>"
} 